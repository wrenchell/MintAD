/*
 * lwldap-error.h
 *
 *  Created on: Nov 6, 2009
 *      Author: wfu
 */

#ifndef LWLDAPERROR_H_
#define LWLDAPERROR_H_

#ifndef LW_STRICT_NAMESPACE
#define Win32ExtErrorToName(winerr)          LwWin32ExtErrorToName(winerr)
#define Win32ExtErrorToDescription(winerr)   LwWin32ExtErrorToDescription(winerr)

#endif /* LW_STRICT_NAMESPACE */

#endif /* LWLDAPERROR_H_ */
